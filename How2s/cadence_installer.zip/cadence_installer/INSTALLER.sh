#!/bin/bash

# Set this to desired install directory
CADENCE_DIR=~/cadence

# Check if Cadence install found, exit if one detected
if [ ! -d $CADENCE_DIR ]
then
    echo "Making Cadence folder at ${CADENCE_DIR}."
    mkdir $CADENCE_DIR
else
    echo "Cadence Installation Found. Please delete ${CADENCE_DIR} folder and try again."
    exit
fi

# Copy files needed files into Cadence folder
cp $(pwd)/bashrc $CADENCE_DIR/.bashrc
cp $(pwd)/bashrc.cadence $CADENCE_DIR/.bashrc.cadence
cp $(pwd)/cdsenv $CADENCE_DIR/.cdsenv
cp $(pwd)/cdsinit $CADENCE_DIR/.cdsinit
cp $(pwd)/cdslocal $CADENCE_DIR/.cdslocal
cp $(pwd)/cds.lib $CADENCE_DIR
cp $(pwd)/runcad $CADENCE_DIR
cp $(pwd)/settings64.sh $CADENCE_DIR

# Copy License configuration into home directory
cp $(pwd)/cdsenv_home ~/.cdsenv

# Copy Desktop Shortcut
cp $(pwd)/Run_Cadence.sh ~/Desktop

# Make Library Folder
mkdir $CADENCE_DIR/Libraries

echo "Files successfully copied!"

cd $CADENCE_DIR
chmod +x runcad 

printf "USERDIR=%s\n" $CADENCE_DIR > ~/.cadence_config.txt
