#!/bin/bash

# Read Config file and get install directory
CFG=$(cat ~/.cadence_config.txt)
USERDIR_STR=(${CFG//=/ })
USERDIR=${USERDIR_STR[1]}
# Make sure Linux Enivonment has the USERDIR Variable set
export USERDIR=$USERDIR

# Start Cadence
cd $USERDIR
module add cadence21

source .bashrc
source .bashrc.cadence

./runcad
