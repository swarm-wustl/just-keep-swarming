WUSTL LinuxLab Cadence Installer V0.1 (last modified 8/6/2023)

SETUP INSTRUCTIONS

1. Extract zip file.
2. Open a terminal in the unzipped directory and run the following command: 'bash INSTALLER.sh'
3. If successful navigate to your Desktop and right click the file 'Run_Cadence.sh'
4. Navigate to Properties > Permissions > and check 'Allow this File to Run as a Program'
5. You should now be able to launch Cadence by double-clicking the 'Run_Cadence.sh' file

TROUBLESHOOTING

1. If the desktop shortcut does not appear to be working try manually running the Shortcut by opening a terminal in the shortcut location and executing 'bash Run_Cadence.sh'
2. If reinstalling make sure to delete the created Cadence folder to ensure a complete reinstall. Make sure to back up your libraries before doing so.
3. You can change the Cadence install location by editing the 'CADENCE_DIR' variable in 'INSTALLER.sh'

QUESTIONS / SUGGESTIONS
If you have any questions or suggestions to improve this installer please contact akilgore@wustl.edu
